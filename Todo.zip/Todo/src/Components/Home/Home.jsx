import React from 'react'

function Home() {
  return (
    <>
      <div className='bond'>
        <div className="container">
          <input type="search" name="search" placeholder='Search'/>
          <button className='ms-4'>Sort</button>
          <div className="box-contain d-flex mt-4">
            <div className="col-3">
              <div className="box-1"></div>            
            </div>
            <div className="col-3">
              <div className="box-2"></div>            
            </div>
            <div className="col-3">
              <div className="box-3"></div>            
            </div>
            <div className="col-3">
              <div className="box-4"></div>            
            </div>
          </div>
          <div className="d-flex mt-4">
            <div className="col-3">
                <div className="box-5"></div>            
            </div>
            <div className="col-3">
              <div className="box-6"></div>            
            </div>
            <div className="col-3">
              <div className="box-7"></div>            
            </div>
            <div className="col-3">
              <div className="box-8"></div>            
            </div>        
          </div>
          <div className="btn-bond d-flex justify-content-center mt-4 ">
            <button className='me-4 p-3'>Prev</button>
            <button className='p-3'>Next</button>
          </div>
        </div>
      </div>
    </>
  )
}

export default Home